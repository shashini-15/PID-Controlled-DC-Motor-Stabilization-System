import RPi.GPIO as GPIO
import time
import csv
from collections import deque
import os

#  PIN SETUP 
ENA = 18
IN1 = 23
IN2 = 24

ENC_A = 17
ENC_B = 27


#  INPUT 
def get_setpoint(msg="Enter setpoint (RPM): "):
    while True:
        try:
            sp = float(input(msg))
            if sp <= 0:
                print("Setpoint must be positive!")
            else:
                return sp
        except ValueError:
            print("Invalid number!")


#  OPEN LOOP 
def open_loop():
    import numpy as np
    import matplotlib.pyplot as plt

    GPIO.setmode(GPIO.BCM)
    GPIO.setup(ENA, GPIO.OUT)
    GPIO.setup(IN1, GPIO.OUT)
    GPIO.setup(IN2, GPIO.OUT)
    GPIO.setup(ENC_A, GPIO.IN)
    GPIO.setup(ENC_B, GPIO.IN)

    GPIO.output(IN1, GPIO.HIGH)
    GPIO.output(IN2, GPIO.LOW)

    pwm = GPIO.PWM(ENA, 1000)
    pwm.start(0)

    count = 0
    ppr = 150
    dt = 0.2

    def encoder_callback(channel):
        nonlocal count
        count += 1

    GPIO.add_event_detect(ENC_A, GPIO.RISING, callback=encoder_callback)

    folder = "Close_loop"
    os.makedirs(folder, exist_ok=True)

    pwm_values = [30, 50, 70]

    for val in pwm_values:
        print(f"\nRunning PWM = {val}%")

        filename = f"{folder}/data_pwm_{val}.csv"
        file = open(filename, "w", newline="")
        writer = csv.writer(file)
        writer.writerow(["time", "rpm"])

        pwm.ChangeDutyCycle(val)
        time.sleep(1)

        count = 0
        start = time.time()
        last = start

        while True:
            now = time.time()
            t = now - start

            if now - last >= dt:
                temp = count
                count = 0
                rpm = (temp * 60) / ppr

                writer.writerow([t, rpm])
                print(f"[OPEN] PWM={val}% | t={t:.2f}s | RPM={rpm:.2f}")

                last = now

            if t > 10:
                break

        file.close()

    pwm.stop()
    GPIO.remove_event_detect(ENC_A)
    GPIO.cleanup()

    # Simple plot
    t30, r30 = load_data(f"{folder}/data_pwm_30.csv")
    t50, r50 = load_data(f"{folder}/data_pwm_50.csv")
    t70, r70 = load_data(f"{folder}/data_pwm_70.csv")

    import matplotlib.pyplot as plt
    plt.figure()
    plt.plot(t30, r30, label="30%")
    plt.plot(t50, r50, label="50%")
    plt.plot(t70, r70, label="70%")
    plt.legend()
    plt.grid()
    plt.savefig(f"{folder}/Close_loop_plot.png")
    plt.close()

    print("Close-loop complete → saved in Close_loop/")

#  LOAD DATA 
def load_data(filename):
    import numpy as np
    t, rpm = [], []
    with open(filename) as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            t.append(float(row[0]))
            rpm.append(float(row[1]))
    return np.array(t), np.array(rpm)


#  PID CORE 
def run_pid(setpoint, duration, folder, filename, sp2=None):
    import numpy as np
    import matplotlib.pyplot as plt

    os.makedirs(folder, exist_ok=True)

    count = 0
    ppr = 150

    def encoder_callback(channel):
        nonlocal count
        count += 1

    # PID GAINS
    Kp, Ki, Kd = 0.18, 0.32, 0.05
    BASE_PWM = 15
    MAX_PWM = 80

    # FILTERS
    dt = 0.2
    alpha = 0.6
    beta = 0.5
    ramp_time = 2

    integral = 0
    derivative = 0
    last_rpm = 0

    rpm_filtered = 0
    rpm_buffer = deque(maxlen=5)

    #  SETUP GPIO 
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(ENA, GPIO.OUT)
    GPIO.setup(IN1, GPIO.OUT)
    GPIO.setup(IN2, GPIO.OUT)
    GPIO.setup(ENC_A, GPIO.IN)
    GPIO.setup(ENC_B, GPIO.IN)

    pwm = GPIO.PWM(ENA, 1000)
    pwm.start(0)

    GPIO.output(IN1, GPIO.HIGH)
    GPIO.output(IN2, GPIO.LOW)

    GPIO.add_event_detect(ENC_A, GPIO.RISING, callback=encoder_callback)

    file = open(f"{folder}/{filename}", "w", newline="")
    writer = csv.writer(file)
    writer.writerow(["time", "rpm", "setpoint", "pwm"])

    pwm.ChangeDutyCycle(0)
    time.sleep(1)

    start = time.time()
    last = start

    try:
        while True:
            now = time.time()
            t = now - start

            if now - last >= dt:
                temp = count
                count = 0
                raw_rpm = (temp * 60) / ppr

                # FILTERING
                rpm_filtered = beta * raw_rpm + (1 - beta) * rpm_filtered
                rpm_buffer.append(rpm_filtered)
                rpm = sum(rpm_buffer) / len(rpm_buffer)

                # SOFT START
                if t < ramp_time:
                    current_sp = setpoint * (t / ramp_time)
                else:
                    if sp2 and t > 15:
                        current_sp = sp2
                    else:
                        current_sp = setpoint

                error = current_sp - rpm
                if abs(error) < 0.5:
                    error = 0

                # PID
                P = Kp * error
                integral += error * dt

                I = Ki * integral

                raw_derivative = -(rpm - last_rpm) / dt
                derivative = alpha * raw_derivative + (1 - alpha) * derivative
                D = Kd * derivative

                output = BASE_PWM + P + I + D

                # LIMIT + ANTI-WINDUP
                if output > MAX_PWM:
                    output = MAX_PWM
                    integral -= error * dt
                elif output < 0:
                    output = 0
                    integral -= error * dt

                pwm.ChangeDutyCycle(output)

                # LOG + PRINT
                writer.writerow([t, rpm, current_sp, output])

                print(f"[PID] t={t:.2f}s | RPM={rpm:.2f} | SP={current_sp:.1f} | PWM={output:.2f}")

                last_rpm = rpm
                last = now

            if t > duration:
                break

    finally:
        file.close()
        pwm.stop()
        GPIO.cleanup()

    plot_pid_advanced(folder, filename)


#  PLOT 
def plot_pid_advanced(folder, filename):
    import numpy as np
    import matplotlib.pyplot as plt
    import csv

    t, rpm, sp, pwm = [], [], [], []

    with open(f"{folder}/{filename}") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t.append(float(row["time"]))
            rpm.append(float(row["rpm"]))
            sp.append(float(row["setpoint"]))
            pwm.append(float(row["pwm"]))

    t = np.array(t)
    rpm = np.array(rpm)
    sp = np.array(sp)
    pwm = np.array(pwm)

    # ===== CALCULATIONS =====
    ss = np.mean(rpm[-10:])
    sse = abs(ss - sp[-1])

    peak = np.max(rpm)
    os_val = ((peak - ss) / ss) * 100 if ss != 0 else 0

    # Rise time (10% → 90%)
    y10 = 0.1 * ss
    y90 = 0.9 * ss

    t1 = t[np.where(rpm >= y10)[0][0]]
    t2 = t[np.where(rpm >= y90)[0][0]]
    tr = t2 - t1

    # Settling time (±2%)
    upper = ss * 1.02
    lower = ss * 0.98

    ts = t[-1]
    for i in range(len(rpm)):
        if np.all((rpm[i:] >= lower) & (rpm[i:] <= upper)):
            ts = t[i]
            break

    print("\n===== PID PERFORMANCE =====")
    print(f"Steady State: {ss:.2f} RPM")
    print(f"Settling Time: {ts:.2f} s")
    print(f"Rise Time: {tr:.2f} s")
    print(f"Overshoot: {os_val:.2f} %")
    print(f"Steady-State Error: {sse:.2f} RPM")

    #  PLOT 1 
    plt.figure()
    plt.plot(t, rpm, label="Measured RPM")
    plt.plot(t, sp, '--', label="Setpoint")

    plt.axhline(ss, linestyle='--', label="Steady State")
    plt.axvline(ts, linestyle='--', label="Settling Time")

    plt.title("PID Speed Control: RPM vs Time")
    plt.xlabel("Time (s)")
    plt.ylabel("RPM")
    plt.legend()
    plt.grid()

    plt.text(ts, ss*0.9, f"Ts={ts:.2f}s")
    plt.text(t2, y90, f"Tr={tr:.2f}s")
    plt.text(t[-1]*0.6, peak, f"Overshoot={os_val:.1f}%")

    plt.savefig(f"{folder}/rpm_vs_time.png")
    plt.close()

    #  PLOT 2 
    plt.figure()
    plt.plot(t, pwm)

    plt.title("Control Output (PWM) vs Time")
    plt.xlabel("Time (s)")
    plt.ylabel("PWM (%)")
    plt.grid()

    plt.savefig(f"{folder}/pwm_vs_time.png")
    plt.close()

    #  PLOT 3 
    error = sp - rpm

    plt.figure()
    plt.plot(t, error)
    plt.axhline(0, linestyle='--')

    plt.title("Control Error vs Time")
    plt.xlabel("Time (s)")
    plt.ylabel("Error (RPM)")
    plt.grid()

    plt.savefig(f"{folder}/error_vs_time.png")
    plt.close()

    print(f"\nPlots saved in {folder}/")

#  MODES 
def pid_mode():
    sp = get_setpoint()
    run_pid(sp, 20, "pid", "pid.csv")


def disturbance_mode():
    sp = get_setpoint()
    run_pid(sp, 30, "disturbance", "disturbance.csv")


def multi_setpoint_mode():
    sp1 = get_setpoint("SP1: ")
    sp2 = get_setpoint("SP2: ")
    run_pid(sp1, 30, "multisetpoint", "multi.csv", sp2)


#  MENU 
def menu():
    while True:
        print("\n===== MENU =====")
        print("1. Open Loop")
        print("2. PID")
        print("3. Disturbance")
        print("4. Multi Setpoint")
        print("0. Exit")

        c = input("Select: ")

        if c == "1":
            open_loop()
        elif c == "2":
            pid_mode()
        elif c == "3":
            disturbance_mode()
        elif c == "4":
            multi_setpoint_mode()
        elif c == "0":
            break
        else:
            print("Invalid")


#  RUN 
if __name__ == "__main__":
    menu()
